import { MESSAGE_TYPES } from "../../lib/constants.js";

async function load() {
  const response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.GET_STATE });
  const state = response.result;

  renderList("[data-inbox]", state.conversations.filter((item) => !item.archivedAt), renderConversation);
  renderList("[data-drafts]", state.drafts.filter((item) => item.status !== "archived"), renderDraft);
  renderList("[data-skills]", state.skills.filter((item) => item.status !== "archived"), renderSkill);
  renderList("[data-variants]", state.variants, renderVariant);
}

function renderList(selector, items, renderer) {
  const container = document.querySelector(selector);
  if (!items.length) {
    container.innerHTML = "<p class='muted'>Nothing here yet.</p>";
    return;
  }

  container.innerHTML = items.slice(0, 12).map(renderer).join("");
}

function renderConversation(item) {
  return `
    <article class="list-card">
      <strong>${escapeHtml(item.selectedText || item.sourceTitle || "Captured conversation")}</strong>
      <span>${escapeHtml(item.sourcePlatform || "other")} · ${escapeHtml(item.captureMode)}</span>
      <div class="action-row">
        <button type="button" data-action="archive-conversation" data-id="${item.id}">Archive</button>
      </div>
    </article>
  `;
}

function renderDraft(item) {
  return `
    <article class="list-card">
      <strong>${escapeHtml(item.name)}</strong>
      <span>${escapeHtml(item.scenario || "Draft skill")}</span>
      <div class="action-row">
        <button type="button" data-action="promote-draft" data-id="${item.id}">Promote to Skill</button>
        <button type="button" data-action="archive-draft" data-id="${item.id}">Archive</button>
      </div>
    </article>
  `;
}

function renderSkill(item) {
  return `
    <article class="list-card">
      <strong>${escapeHtml(item.name)}</strong>
      <span>${escapeHtml(item.scenario || "Reusable workflow")} · Used ${item.usageCount || 0} times</span>
      <div class="action-row">
        <button type="button" data-action="create-variant" data-id="${item.id}">New Variant</button>
        <button type="button" data-action="archive-skill" data-id="${item.id}">Archive</button>
      </div>
    </article>
  `;
}

function renderVariant(item) {
  return `
    <article class="list-card">
      <strong>${escapeHtml(item.name)}</strong>
      <span>${escapeHtml(item.changeSummary || "Variant")} · Base ${escapeHtml(item.baseSkillId)}</span>
    </article>
  `;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;")
    .replaceAll("'", "&#039;");
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === MESSAGE_TYPES.STORAGE_UPDATED) {
    load();
  }
});

document.addEventListener("click", async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) {
    return;
  }

  const action = target.dataset.action;
  const id = target.dataset.id;
  if (!action || !id) {
    return;
  }

  if (action === "promote-draft") {
    await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.PROMOTE_DRAFT, payload: { draftId: id } });
  }

  if (action === "create-variant") {
    await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.CREATE_VARIANT, payload: { skillId: id } });
  }

  if (action === "archive-conversation") {
    await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.ARCHIVE_CONVERSATION, payload: { conversationId: id } });
  }

  if (action === "archive-draft") {
    await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.ARCHIVE_DRAFT, payload: { draftId: id } });
  }

  if (action === "archive-skill") {
    await chrome.runtime.sendMessage({ type: MESSAGE_TYPES.ARCHIVE_SKILL, payload: { skillId: id } });
  }
});

load();
